package com.cg.payroll.client;
import java.util.Scanner;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		PayrollServices services=new PayrollServicesImpl();
		Scanner sc=new Scanner(System.in);
		int associateId=services.acceptAssociateDetails("Saptarshi", "Das", "sdas@gmail.com", "IT", "Analyst", "AGHGSJD", 80000, 30000, 15000, 5000, 11111, "CITI", "CITI00009");
		System.out.println("Associate Id:- "+associateId);
		int associateId2=services.acceptAssociateDetails("f", "c", "fc@gmail.com", "IT", "Analyst", "DHFJDDD", 85000, 15000, 25000, 6000, 22222, "HDFC", "HDFC00009");
		System.out.println("Associate Id:- "+associateId2);
		System.out.println("Enter the employee id you want to search: ");
		int num=sc.nextInt();
		System.out.println(services.getAssociateDetails(num));
		double netSalary=services.calculateNetSalary(associateId);
		double grossSalary=services.calculateAnnualGrossSalary(associateId);
		System.out.println("------------");
		System.out.println("Net Salary for EmpId "+ associateId+" is "+netSalary);
		System.out.println("Annual GrossSalary for EmpId "+associateId+" is "+grossSalary);
		netSalary=services.calculateNetSalary(associateId2);
		grossSalary=services.calculateAnnualGrossSalary(associateId2);
		System.out.println("Net Salary for EmpId "+ associateId2+" is "+netSalary);
		System.out.println("Annual GrossSalary for EmpId "+associateId2+" is "+grossSalary);
	}
}
