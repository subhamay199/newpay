Set serveroutput on;
<<outer_block>>
DECLARE
Var_num1 NUMBER := 5;
BEGIN
<<inner_block>>
Declare
Var_num1  NUMBER:=10;
BEGIN
DBMS_OUTPUT.PUT_LINE('Value for outer block: ' || outer_block.Var_num1);
End;
End;
/
