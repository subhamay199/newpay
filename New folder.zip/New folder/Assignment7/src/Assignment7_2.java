
public class Assignment7_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
