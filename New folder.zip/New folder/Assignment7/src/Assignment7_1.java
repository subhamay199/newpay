import java.util.Arrays;

public class Assignment7_1 
{
	public static int reverse(int p)
	{
		int n=p,r=0;
		int[] b=new int[n];
		int j=n;
		while(n!=0)
		{
			r=r*10;
			r+=n%10;
			n=n/10;
		}
		return r;
	}
	public static void getSorted(int a[])
	{
		int n=a.length;
		int[] b=new int[n];
		int j=n;
		for(int i=0;i<n;i++)
		{
			a[i]=reverse(a[i]);
			b[j-1]=a[i];
			j--;
		}
		Arrays.sort(a);
	}
	public static void main(String[] args) 
	{
		int[] a={10,50,8,85,4};
		getSorted(a);
		int n=a.length;
		for(int k=0;k<n;k++)
		{
			System.out.print(a[k]+" ");
		}
 	}
}
