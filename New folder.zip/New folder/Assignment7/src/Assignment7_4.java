import java.util.HashMap;
import java.util.Iterator;


public class Assignment7_4 {
	public static HashMap getSquares(int[] array) {
	    HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
	 
	    for (int no: array) {
	      map.put( no, no*no);
	    }
	    return map;
	  }
	 
	  public static void main(String[] args) {
	    int array[] = new int[]{10,30,20,40,60,80,9};
	    HashMap<Integer, Integer> map =getSquares(array);
	 
	    Iterator<Integer> it = map.keySet().iterator();
	    while(it.hasNext()){
	    Integer key = it.next();
	      System.out.println(key + " : " + map.get(key));
	    }
	  }
}
