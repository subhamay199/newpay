import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class Assignment7_3 {
	public static ArrayList<Integer> removeElements() {
		List<String> al=new ArrayList<String>();  
		al.add("Amit");  
		al.add("Vijay");  
		al.add("Kumar");  
		al.add(1,"Sachin");  
		System.out.println("An element at 2nd position: "+al.get(2));  
		for(String s:al){  
		 System.out.println(s);  
		}
		return null; 
	  }

	public static void main(String[] args){
		
   ArrayList<Integer> arr =Assignment7_3.removeElements();        // You can catch the returned integer arraylist into an arraylist.
 }
}
