public class PersonMain {

	public static void main(String[] args) {
		Person ob1=new Person("Subhamay","Samanta",'k',54327);
		//System.out.println(ob1.getFirstname()+" "+ob1.getLastname()+" "+ob1.getGender()+" "+ob1.getPhoneno());
		// TODO Auto-generated method stub
		try
		{
			ob1.getFirstname();
		}
		catch(BlankNameException e)
		{
			System.out.println(e);
		}
	}

}
