public class Account 
{
	long accNum;
	 double balance;
	 Person accHolder;
	//private Person person;
	public Account(){
		accNum=0;
		accHolder=null;
		balance=500;
	}
	
	public Account(long accNum, Person accHolder) {
		//super();
		this.accNum = accNum;
		//this.balance = balance;
		this.accHolder = accHolder;
		//this.person=person;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	 public void deposit(double d)
	{
		balance+=d;
	}
	 public void withdraw(double amt) throws InsufficientBalanceException, OverDraftLimitException
		{
		 if(balance-amt>500)
			balance-=amt;
		 else
			throw new InsufficientBalanceException();
		}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	 
	 
}
