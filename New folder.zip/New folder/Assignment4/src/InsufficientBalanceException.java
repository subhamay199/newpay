
public class InsufficientBalanceException extends Exception {
	 public InsufficientBalanceException()
	 {
		 System.out.println("Balance Can't Be Withdrawn");
	 }
}
