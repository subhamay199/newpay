package com.cg.eis.service;

import com.cg.eis.bean.*;

public class EmployeeInsuranceSystemService implements EmployeeService
{
	
	private Employee[] empList;

	public EmployeeInsuranceSystemService(int noOfEmp)
	{
		this.empList=new Employee[noOfEmp];
	}
	
	public void addEmployeeDetails(int id, String name, double Salary,
			Designation designation, Insurance insuranceScheme) {

		if(id>0 && id<this.empList.length)
		{
			//double salary;
			this.empList[id]=new Employee(id,name,Salary,designation,insuranceScheme);
		}
		
	}
	public Insurance showInsuranceSchemes(int id,double salary,Designation designation) 
	{
		if(id>0 && id<this.empList.length)
		{
			if(salary>=40000 && designation==Designation.Manager)
			{
			return Insurance.SchemeA;
			}
			else if(salary>20000 && salary<40000 && designation==Designation.Programmer)
			{
				return Insurance.SchemeB;
			}
			else if(salary>5000 && salary<20000 && designation==Designation.SystemAssociate)
			{
				return Insurance.SchemeC;
			}	
			else if( salary<5000 && designation==Designation.Clerk)
			{
				return Insurance.NoScheme;
			}	
		}
		return null;
	}

	
	public void disEmployeeDeatils(int id) {
		if(id>0 && id<this.empList.length)
			System.out.println(this.empList[id].toString());
		
	}
	

}
