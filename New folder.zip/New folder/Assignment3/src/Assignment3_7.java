import java.util.Scanner;


public class Assignment3_7 
{
	public static boolean validate(String fn,String ln)
	{
		int len=fn.length()+ln.length()+1;
		if(len<8)
		{
			return false;
		}
		else
		{
			String str2="_job";
			fn=fn+ln;
			fn=fn+str2;
			System.out.println("Applicant' Name is: "+fn);
			return true;
		}
	}
	public static void main(String[] args)
	{
		System.out.println("Enter The First Name Of The applicant:");
		Scanner sc=new Scanner(System.in);
		String fn=sc.next();
		System.out.println("Enter The Last Name Of The applicant:");
		String ln=sc.next();
		
		if(validate(fn,ln)==true)
		{
			System.out.println("Accepted");
		}
		else
			System.out.println("Rejected!Minimum 8 charecters Required");
	}
}

