import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.util.Scanner;
import java.util.TimeZone;

public class Assignment3_6
{
	public static void printtime(String str)
				{				
					Date today=new Date();
					DateFormat df=new SimpleDateFormat("dd-MM-YY HH:mm:ss ");
					df.setTimeZone(TimeZone.getTimeZone(str));
					String Ist=df.format(today);
					System.out.println("Date in TimeZone: "+Ist);
				}
			public static void main(String[] args) 
			{
				
				System.out.println("Enter Time Zone id:");
				Scanner sc=new Scanner(System.in);
				String str=sc.next();
				printtime(str);
			}
}
