import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
public class StringManipulation {
	public static void concatination(String st)
	{		
		st=st+st;
		//st=st.concat(st);
		System.out.println(st);
	}
	public static void replacement(String str)
	{
			for(int i=0;i<=str.length();i++)
		{
			if(i%2!=0)
			{
				str=str.substring(0,i-1)+"#"+str.substring(i,str.length());
			}
		}
		System.out.println(str);
	}
	public static void removalDuplicate(String str)
	{
		//Scanner sc=new Scanner(System.in);
		
		char ch[]=str.toCharArray();
		Set<Character> charSet=new LinkedHashSet<Character>();
		for(char c: ch)
		{charSet.add(c);}
		StringBuilder sb=new StringBuilder();
		for(Character character: charSet){sb.append(character);}
		System.out.println(sb.toString());
	}
	public static void oddCharecterToUppercase(String str)
	{
		Scanner sc=new Scanner(System.in);
		
		char ch[]=str.toCharArray();
		for(int i=1;i<str.length();i=i+2)
		{
			if(ch[i]>='a' && ch[i]<='z')
			{
				ch[i]=(char)(ch[i]-'a'+'A');
			}
		}
		System.out.println(ch);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1 for add string");
		System.out.println("Enter 2 for Replacing odd positions with #");
		System.out.println("Enter 3 for Removing duplicate characters");
		System.out.println("Enter 4 for changing odd characters to upper case");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:	
			System.out.println("Enter the string");
			String st=sc.next();
			concatination(st);break;
		case 2:

			System.out.println("Enter the string");
			String str=sc.next();
			replacement(str);break;
		case 3:	System.out.println("Enter the string");
				String str1=sc.next();
				removalDuplicate(str1);break;
		case 4:System.out.println("Enter the string");
		
				String str2=sc.next();
			
				oddCharecterToUppercase(str2);break;
		default:System.out.println("Wrong Choice"); 
		}

	}

}
