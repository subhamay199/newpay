package com.cg.ticketing.services;

import com.cg.ticketing.beans.ReservedTicket;

public interface TicketingServices {
	String book(ReservedTicket reservedTicket);
	boolean cancel(String pnr);
	ReservedTicket get(ReservedTicket pnr);
	void put(int pnr, ReservedTicket pnr2);
	void put(int pnr, ReservedTicket pnr2);

}
