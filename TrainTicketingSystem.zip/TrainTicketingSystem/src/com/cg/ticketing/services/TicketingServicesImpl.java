package com.cg.ticketing.services;

import com.cg.ticketing.beans.ReservedTicket;

public class TicketingServicesImpl implements TicketingServices {

	@Override
	public String book(ReservedTicket reservedTicket) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean cancel(String pnr) {
		// TODO Auto-generated method stub
		return false;
	}

}
