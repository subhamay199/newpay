package com.cg.ticketing.util;

import java.util.HashMap;

import com.cg.ticketing.services.TicketingServices;
import com.cg.ticketing.services.TicketingServicesImpl;


public class TrainTicketingDBUtil {
	
public static TicketingServices service=new TicketingServicesImpl();
	private static int Ticket_ID_COUNTER=100;
	public static String accountStatus = "Booked";
	
	private static int pinNumber=(int) (Math.random()*1000);
	public static int getPIN_NUMBER() {
		return ++pinNumber;
	}
	public static String getACCOUNT_STATUS() {
	//	String accountStatus;
		return accountStatus;
	}
	public static int getTicket_ID_COUNTER() {
		// TODO Auto-generated method stub
		return ++Ticket_ID_COUNTER;	}
	
}
