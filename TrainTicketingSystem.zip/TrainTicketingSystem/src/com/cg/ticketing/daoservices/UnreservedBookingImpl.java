package com.cg.ticketing.daoservices;

import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.beans.UnReservedTicket;

public class UnreservedBookingImpl implements UnReservedBookingDAO{

	@Override
	public UnReservedTicket save(UnReservedTicket ticketId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UnReservedTicket findOne(UnReservedTicket ticketId) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
