package com.cg.ticketing.daoservices;
import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.util.TrainTicketingDBUtil;

public class ReservedBookingImpl implements ReservedBookingDAO {
	ReservedTicket reserved;

	@Override
	public ReservedTicket save(ReservedTicket pnr) {
		pnr.setPnr(TrainTicketingDBUtil.getTicket_ID_COUNTER());
		TrainTicketingDBUtil.service.put((int) pnr.getPnr(),pnr);
		return pnr;
	}

	@Override
	public ReservedTicket findOne(ReservedTicket pnr) {
		// TODO Auto-generated method stub
		return TrainTicketingDBUtil.service.get(pnr);
	}
	


}
