package com.cg.ticketing.util;
import java.util.HashMap;
import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.beans.UnReservedTicket;
public class TrainTicketingDBUtil {
	
//public static TicketingServices service=new TicketingServicesImpl();
public static HashMap<Integer, ReservedTicket>service = new HashMap<>();
public static HashMap<Integer, UnReservedTicket> unreservedService = new HashMap<>();
	private static int Ticket_ID_COUNTER=100;
	public static String accountStatus = "Booked";
	
	public static int getPNR() {
		return (int) (Math.random()*1000);
	}
	public static String getACCOUNT_STATUS() {
	//	String accountStatus;
		return accountStatus;
	}
	public static int getTicket_ID_COUNTER() {
		// TODO Auto-generated method stub
		return ++Ticket_ID_COUNTER;	}
	
}
