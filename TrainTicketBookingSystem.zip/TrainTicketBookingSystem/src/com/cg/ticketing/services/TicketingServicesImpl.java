package com.cg.ticketing.services;

import java.util.List;
import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.beans.TrainTicket;
import com.cg.ticketing.beans.UnReservedTicket;
import com.cg.ticketing.daoservices.ReservedBookingDAO;
import com.cg.ticketing.daoservices.ReservedBookingImpl;
import com.cg.ticketing.daoservices.UnReservedBookingDAO;
import com.cg.ticketing.daoservices.UnreservedBookingImpl;

public class TicketingServicesImpl implements TicketingServices {
	private  ReservedBookingDAO reserved=new ReservedBookingImpl();
	private  UnReservedBookingDAO unreserved=new UnreservedBookingImpl();
	@Override
	public ReservedTicket bookReserved(ReservedTicket reservedTicket) {
		reservedTicket=reserved.save(reservedTicket);
		return reservedTicket;
	}
	@Override
	public ReservedTicket cancelReserved(ReservedTicket reservedTicket) {
		reservedTicket=reserved.delete(reservedTicket);
		return reservedTicket;
	}
	@Override
	public UnReservedTicket bookUnReserved(UnReservedTicket unReservedTicket) {
		unReservedTicket=unreserved.save(unReservedTicket);
		return unReservedTicket;
	}

	@Override
	public UnReservedTicket cancelUnReserved(UnReservedTicket unReservedTicket) {
		unReservedTicket=unreserved.delete(unReservedTicket);
		return unReservedTicket;
	}
}
