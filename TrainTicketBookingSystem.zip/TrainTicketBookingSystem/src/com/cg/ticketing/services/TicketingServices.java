package com.cg.ticketing.services;

import java.util.List;

import com.cg.ticketing.beans.ReservedTicket;
import com.cg.ticketing.beans.TrainTicket;
import com.cg.ticketing.beans.UnReservedTicket;

public interface TicketingServices {
ReservedTicket bookReserved(ReservedTicket reservedTicket);
ReservedTicket cancelReserved(ReservedTicket reservedTicket);
UnReservedTicket bookUnReserved(UnReservedTicket unReservedTicket);
UnReservedTicket cancelUnReserved(UnReservedTicket unReservedTicket);
}
