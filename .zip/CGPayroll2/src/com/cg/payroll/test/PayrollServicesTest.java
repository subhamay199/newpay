package com.cg.payroll.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;

import junit.framework.Assert;

public class PayrollServicesTest {

	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	private static PayrollServices services;
	@BeforeClass
	private static void setUpTestEnv()
	{
		services = new PayrollServicesImpl();
	}
	
	@Before
	public void setUpTestData() {
		Associate associate1=new Associate(101,78000,"S","M","T","Mngr","DTD","satish@cg.com",new Salary(35000,1800,1800),new BankDetails(12345,"HDFC","savings"));
		Associate associate2=new Associate(101,78000,"T","P","S","Mgr","DD","sish@cg.com",new Salary(3500,100,180),new BankDetails(1245,"HFC","savgs"));
		PayrollDBUtil.associates.put(associate1.getAssociateId(), associate1);
		PayrollDBUtil.associates.put(associate2.getAssociateId(), associate2);
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
		}
	
	@Test
	public void testGetAllAssociateDetails() {
		Associate associate1=new Associate(101,78000,"S","M","T","Mngr","DTD","satish@cg.com",new Salary(35000,1800,1800),new BankDetails(12345,"HDFC","savings"));
		Associate associate2=new Associate(101,78000,"T","P","S","Mgr","DD","sish@cg.com",new Salary(3500,100,180),new BankDetails(1245,"HFC","savgs"));
		ArrayList <Associate> expectedAssociateList = new ArrayList<>();
		expectedAssociateList.add(associate1);
		expectedAssociateList.add(associate2);
		ArrayList <Associate> actualAssociateList = (ArrayList<Associate>) services.getAllAssociateDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}
	public void testAcceptAssociateDetailsForValidData() {
		int expectedId=103;
		int actualId=services.acceptAssociateDetails("AB", "cd", "abc@xy", "department", "designation", "pancard", 100, 200, 10, 20, 12345, "bankName", "ifscCode");
		Assert.assertEquals(expectedId, actualId);
	}
	
	@Test(expected = AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		services.calculateNetSalary(1434);
	}
	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotFoundException{
		int expectedNetSalary=0;
		double actualNetSalary=services.calculateNetSalary(102);
		Assert.assertEquals(expectedNetSalary, actualNetSalary);
	}
	
	@AfterClass
	private static void tearDownTestEnv()
	{
		services = null;
	}

}
